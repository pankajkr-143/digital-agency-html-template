import { motion } from "framer-motion";

const teamMembers = [
  { name: "Aarav Sharma", role: "Founder & CEO", img: "https://randomuser.me/api/portraits/men/32.jpg" },
  { name: "Neha Verma", role: "CTO", img: "/assets/mehul.jpeg" },
  { name: "Rohit Singh", role: "Lead Developer", img: "https://randomuser.me/api/portraits/men/54.jpg" },
  { name: "Pooja Mehta", role: "UI/UX Designer", img: "https://randomuser.me/api/portraits/women/65.jpg" },
  { name: "Aditya Jain", role: "Backend Engineer", img: "https://randomuser.me/api/portraits/men/76.jpg" },
  { name: "Simran Kaur", role: "Frontend Developer", img: "https://randomuser.me/api/portraits/women/68.jpg" },
  { name: "Kunal Patel", role: "DevOps Engineer", img: "https://randomuser.me/api/portraits/men/85.jpg" },
  { name: "Ananya Gupta", role: "AI Engineer", img: "https://randomuser.me/api/portraits/women/21.jpg" },
  { name: "Vikas Yadav", role: "Project Manager", img: "https://randomuser.me/api/portraits/men/41.jpg" },
];

export default function OurTeam() {
  return (
    <section className="min-h-screen bg-[#0b1220] py-20 px-6">
      
      {/* HEADER */}
      <div className="max-w-7xl mx-auto text-center mb-14">
        <h1 className="text-4xl md:text-5xl font-bold text-white">
          Meet Our <span className="text-blue-400">Team</span>
        </h1>
        <p className="mt-4 text-gray-400 max-w-2xl mx-auto">
          A passionate team of developers, designers, and innovators building
          future-ready digital solutions.
        </p>
      </div>

      {/* TEAM GRID */}
      <div className="max-w-7xl mx-auto grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
        {teamMembers.map((member, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: i * 0.08 }}
            whileHover={{ y: -10 }}
            className="
              bg-[#111a2e]
              rounded-2xl
              p-6
              text-center
              border border-white/10
              shadow-[0_20px_40px_rgba(0,0,0,0.4)]
              group
            "
          >
            {/* IMAGE */}
            <div className="relative mx-auto w-28 h-28 rounded-full overflow-hidden">
              <img
                src={member.img}
                alt={member.name}
                className="
                  w-full h-full object-cover
                  transition-transform duration-500
                  group-hover:scale-110
                "
              />
              <div className="absolute inset-0 rounded-full ring-2 ring-blue-400/40"></div>
            </div>

            {/* INFO */}
            <h3 className="mt-4 text-xl font-semibold text-white">
              {member.name}
            </h3>
            <p className="text-sm text-blue-400 mt-1">
              {member.role}
            </p>

            {/* SOCIALS (dummy) */}
            <div className="flex justify-center gap-4 mt-4 text-gray-400">
              <span className="hover:text-blue-400 cursor-pointer">in</span>
              <span className="hover:text-blue-400 cursor-pointer">tw</span>
              <span className="hover:text-blue-400 cursor-pointer">gh</span>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
