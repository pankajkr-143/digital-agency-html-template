export default function NotFound() {
  return (
    <div className="pt-24 min-h-screen text-center">
      <h1 className="text-3xl font-bold">404 - Page Not Found</h1>
    </div>
  );
}
