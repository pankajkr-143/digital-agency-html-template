export default function InternshipFormPage() {
  return (
    <section className="min-h-screen bg-[#0b1220] text-white px-6 py-20">
      <div className="max-w-5xl mx-auto bg-[#0f1a30] border border-blue-500/40 rounded-2xl p-10 shadow-[0_0_40px_rgba(59,130,246,0.35)]">

        {/* TITLE */}
        <h1 className="text-3xl font-bold text-center text-blue-400 mb-10">
          Internship Application Form
        </h1>

        {/* ================= PERSONAL DETAILS ================= */}
        <h2 className="section-title">Personal Details</h2>

        <div className="grid md:grid-cols-2 gap-6">
          <Input label="Full Name*" />
          <Input label="Date of Birth" type="date" />
          <Select label="Gender" options={["Select", "Male", "Female", "Other"]} />
          <Input label="Email ID*" />
          <Input label="Phone Number*" />
          <Input label="Alternate Contact Number" />
        </div>

        <Input label="Full Address" className="mt-6" />

        <div className="grid md:grid-cols-2 gap-6 mt-6">
          <Input label="City" />
          <Input label="State" />
        </div>

        <Input label="PIN Code" className="mt-6" />

        {/* ================= EDUCATIONAL BACKGROUND ================= */}
        <h2 className="section-title mt-12">Educational Background</h2>

        <div className="grid md:grid-cols-2 gap-6">
          <Input label="Current College / University" />
          <Input label="Degree Pursuing" />
          <Input label="Branch / Stream" />
          <Input label="Current Year / Semester" />
          <Input label="Expected Graduation Year" />
          <Input label="10th Percentage / CGPA" />
          <Input label="12th Percentage / CGPA" />
          <Input label="Current CGPA" />
        </div>

        {/* ================= INTERNSHIP PREFERENCES ================= */}
        <h2 className="section-title mt-12">Internship Preferences</h2>

        <div className="grid md:grid-cols-2 gap-6">
          <Input label="Preferred Internship Domain (e.g. Web Dev, AI, Cybersecurity)" />
          <Input label="Internship Duration (weeks/months)" />
          <Input label="Availability Start Date" type="date" />
          <Select
            label="Mode of Internship"
            options={["Select", "Remote", "Onsite", "Hybrid"]}
          />
        </div>

        <Input label="Location Preference (if any)" className="mt-6" />

        {/* ================= SKILL SET ================= */}
        <h2 className="section-title mt-12">Skill Set</h2>

        <p className="text-sm text-blue-300 mb-2">
          Programming Languages Known
        </p>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          {["C", "C++", "Java", "Python", "JavaScript", "TypeScript", "Go", "Ruby", "Other"].map(
            (lang) => (
              <label key={lang} className="flex items-center gap-2 text-sm">
                <input type="checkbox" className="accent-blue-500" />
                {lang}
              </label>
            )
          )}
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <Input label="Tools / Technologies Familiar With" />
          <Input label="Certifications (if any)" />
        </div>

        <div className="grid md:grid-cols-2 gap-6 mt-6">
          <Input label="Portfolio / GitHub Link (optional)" />
          <Input label="LinkedIn Profile URL (optional)" />
        </div>

        <Input
          label="Resume (Upload on Google Drive & paste link here)"
          placeholder="https://drive.google.com/..."
          className="mt-6"
        />

        {/* ================= OTHER INFO ================= */}
        <h2 className="section-title mt-12">Other Info</h2>

        <Textarea label="Why do you want to join this internship?" />

        <div className="grid md:grid-cols-2 gap-6 mt-6">
          <Select
            label="Are you available full-time or part-time?"
            options={["Select", "Full-time", "Part-time"]}
          />
          <Input label="Any previous internship experience?" />
        </div>

        <Input label="Referral (if any)" className="mt-6" />

        <label className="flex items-start gap-3 mt-6 text-sm text-blue-300">
          <input type="checkbox" className="accent-blue-500 mt-1" />
          I hereby declare that the information provided is true and I consent
          to the processing of my data.*
        </label>

        <div className="grid md:grid-cols-2 gap-6 mt-6">
          <Input label="Signature / Typed Name" />
          <Input label="Date of Submission" type="date" />
        </div>

        <button className="w-full mt-10 py-3 rounded-xl bg-blue-500 text-black font-semibold hover:bg-blue-400 transition">
          Submit Application
        </button>
      </div>

      {/* ================== STYLES ================== */}
      <style>{`
        .section-title {
          font-size: 1.25rem;
          font-weight: 600;
          color: #60a5fa;
          margin-bottom: 1rem;
        }
        .field {
          background: #020617;
          border: 1px solid rgba(59,130,246,.4);
          padding: 12px;
          border-radius: 10px;
          width: 100%;
        }
        .field:focus {
          outline: none;
          border-color: #3b82f6;
          box-shadow: 0 0 15px rgba(59,130,246,.45);
        }
      `}</style>
    </section>
  );
}

/* ================== REUSABLE INPUTS ================== */

function Input({ label, type = "text", placeholder, className = "" }) {
  return (
    <div className={className}>
      <label className="block text-sm text-blue-300 mb-1">{label}</label>
      <input type={type} placeholder={placeholder} className="field" />
    </div>
  );
}

function Select({ label, options }) {
  return (
    <div>
      <label className="block text-sm text-blue-300 mb-1">{label}</label>
      <select className="field">
        {options.map((opt) => (
          <option key={opt}>{opt}</option>
        ))}
      </select>
    </div>
  );
}

function Textarea({ label }) {
  return (
    <div className="mt-6">
      <label className="block text-sm text-blue-300 mb-1">{label}</label>
      <textarea rows="4" className="field" />
    </div>
  );
}
