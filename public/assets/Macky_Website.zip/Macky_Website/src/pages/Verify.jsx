import VerifyCertificate from "../components/VerifyCertificate";

export default function Verify() {
  return (
    <div className="pt-24 min-h-screen bg-gray-100">
      <VerifyCertificate />
    </div>
  );
}
