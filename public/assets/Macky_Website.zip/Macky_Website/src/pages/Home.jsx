import { useEffect } from "react";

import Services from "../components/Services";
import Process from "../components/Process";
import WhyChooseUs from "../components/WhyChooseUs";
import Testimonials from "../components/Testimonials";
import HeroSection from "../components/HeroSection";
import Hero2 from "../components/Hero2";
import SmoothScroll from "../components/SmoothScroll";
import Spotlight from "../components/Spotlight";

export default function Home({ setShowNavbar }) {

  useEffect(() => {
    const handleScroll = () => {
      const heroHeight = window.innerHeight * 2;

      if (window.scrollY >= heroHeight - 50) {
        setShowNavbar(true);
      } else {
        setShowNavbar(false);
      }
    };

    window.addEventListener("scroll", handleScroll);

    return () => window.removeEventListener("scroll", handleScroll);
  }, [setShowNavbar]);

  return (
    <main>
      <SmoothScroll>
        <HeroSection />
        
         <Services />
        <Process />
       <WhyChooseUs />
        <Testimonials />
        <Spotlight/>
      </SmoothScroll>
    </main>
  );
}
