import {
  motion,
  useScroll,
  useTransform,
  useSpring,
} from "framer-motion";
import { useRef, useState } from "react";

export default function Services() {
  const sectionRef = useRef(null);

  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start start", "end end"],
  });

  const smooth = {
    stiffness: 75,
    damping: 20,
    mass: 1.2,
  };

  const box1X = useSpring(
    useTransform(scrollYProgress, [0.08, 0.18, 0.38, 0.6], [0, -40, -80, -120]),
    smooth
  );

  const box2X = useSpring(
    useTransform(
      scrollYProgress,
      [0.16, 0.26, 0.46, 0.68],
      ["110vw", "0px", "-40px", "-80px"]
    ),
    smooth
  );
  const box2Opacity = useSpring(
    useTransform(scrollYProgress, [0.16, 0.19], [0, 1]),
    smooth
  );

  const box3X = useSpring(
    useTransform(
      scrollYProgress,
      [0.3, 0.4, 0.62],
      ["110vw", "0px", "-40px"]
    ),
    smooth
  );
  const box3Opacity = useSpring(
    useTransform(scrollYProgress, [0.3, 0.33], [0, 1]),
    smooth
  );

  const box4X = useSpring(
    useTransform(scrollYProgress, [0.44, 0.56], ["110vw", "0px"]),
    smooth
  );
  const box4Opacity = useSpring(
    useTransform(scrollYProgress, [0.44, 0.47], [0, 1]),
    smooth
  );

  return (
    <section
      ref={sectionRef}
      className="relative h-[500vh]"
      style={{
        backgroundImage: `
          linear-gradient(rgba(5,10,20,0.85), rgba(5,10,20,0.9)),
          url('https://images.unsplash.com/photo-1446776811953-b23d57bd21aa')
        `,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
      }}
    >
      <div className="sticky top-0 h-screen overflow-hidden flex items-center">
        <div className="w-full max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 items-center px-6 lg:px-12 gap-8 lg:gap-16">

          {/* LEFT SIDE */}
          <div className="space-y-6 lg:space-y-8">
            <h1 className="text-4xl md:text-5xl lg:text-7xl font-extrabold leading-tight text-white">
              Crafted With <br />
              <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
                Precision & Code.
              </span>
            </h1>

            <p className="text-slate-300 text-base md:text-lg lg:text-xl max-w-md leading-relaxed font-light">
              We build scalable platforms and secure digital systems engineered for performance and growth.
            </p>

            <div className="w-16 lg:w-24 h-[3px] bg-gradient-to-r from-cyan-400 to-transparent rounded-full"></div>
          </div>

          {/* RIGHT SIDE CARDS */}
          <div className="relative w-full max-w-[600px] h-[300px] lg:h-[400px] lg:justify-self-end hidden lg:block">

            <PremiumCard x={box1X} z={10}
              title="Web Development"
              desc="Modern web systems with secure architecture."
              items={["React", "Next.js", "APIs", "Optimization"]}
            />

            <PremiumCard x={box2X} opacity={box2Opacity} z={20}
              title="App Development"
              desc="High-performance cross-platform applications."
              items={["Flutter", "Firebase", "Realtime", "Deployment"]}
            />

            <PremiumCard x={box3X} opacity={box3Opacity} z={30}
              title="Cloud Architecture"
              desc="Scalable infrastructure with CI/CD automation."
              items={["AWS", "Docker", "Monitoring", "Security"]}
            />

            <PremiumCard x={box4X} opacity={box4Opacity} z={40}
              title="Digital Security"
              desc="Advanced validation and encryption systems."
              items={["Encryption", "QR Verify", "Admin", "API"]}
            />

          </div>

          {/* MOBILE SERVICES CARDS */}
          <div className="lg:hidden space-y-6 mt-12">
            <div className="bg-slate-900/80 backdrop-blur-2xl border border-white/10 rounded-2xl p-6">
              <h2 className="text-2xl font-semibold text-white mb-3">Web Development</h2>
              <p className="text-slate-300 mb-4">Modern web systems with secure architecture.</p>
              <div className="grid grid-cols-2 gap-3 text-sm">
                {["React", "Next.js", "APIs", "Optimization"].map((item, i) => (
                  <div key={i} className="flex items-center gap-2 text-slate-300">
                    <span className="w-2 h-2 bg-cyan-400 rounded-full"></span>
                    {item}
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-slate-900/80 backdrop-blur-2xl border border-white/10 rounded-2xl p-6">
              <h2 className="text-2xl font-semibold text-white mb-3">App Development</h2>
              <p className="text-slate-300 mb-4">High-performance cross-platform applications.</p>
              <div className="grid grid-cols-2 gap-3 text-sm">
                {["Flutter", "Firebase", "Realtime", "Deployment"].map((item, i) => (
                  <div key={i} className="flex items-center gap-2 text-slate-300">
                    <span className="w-2 h-2 bg-cyan-400 rounded-full"></span>
                    {item}
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-slate-900/80 backdrop-blur-2xl border border-white/10 rounded-2xl p-6">
              <h2 className="text-2xl font-semibold text-white mb-3">Cloud Architecture</h2>
              <p className="text-slate-300 mb-4">Scalable infrastructure with CI/CD automation.</p>
              <div className="grid grid-cols-2 gap-3 text-sm">
                {["AWS", "Docker", "Monitoring", "Security"].map((item, i) => (
                  <div key={i} className="flex items-center gap-2 text-slate-300">
                    <span className="w-2 h-2 bg-cyan-400 rounded-full"></span>
                    {item}
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-slate-900/80 backdrop-blur-2xl border border-white/10 rounded-2xl p-6">
              <h2 className="text-2xl font-semibold text-white mb-3">Digital Security</h2>
              <p className="text-slate-300 mb-4">Advanced validation and encryption systems.</p>
              <div className="grid grid-cols-2 gap-3 text-sm">
                {["Encryption", "QR Verify", "Admin", "API"].map((item, i) => (
                  <div key={i} className="flex items-center gap-2 text-slate-300">
                    <span className="w-2 h-2 bg-cyan-400 rounded-full"></span>
                    {item}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}


/* CLEAN POPUP CARD (NO LIGHT EFFECT) */
function PremiumCard({ x, opacity = 1, z, title, desc, items }) {
  const [hovered, setHovered] = useState(false);

  return (
    <motion.div
      style={{
        x,
        opacity,
        zIndex: hovered ? 999 : z,
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      animate={{
        scale: hovered ? 1.12 : 1,
        y: hovered ? -20 : 0,
      }}
      transition={{ type: "spring", stiffness: 260, damping: 20 }}
      className="absolute inset-0 ml-15 rounded-3xl"
    >
      <div className="h-full w-full rounded-3xl 
        bg-slate-900/80 backdrop-blur-2xl 
        border border-white/10 
        p-10 flex flex-col justify-between
        shadow-xl
        cursor-pointer">

        <div>
          <h2 className="text-3xl font-semibold text-white mb-4 tracking-wide">
            {title}
          </h2>
          <p className="text-slate-300 leading-relaxed font-light">
            {desc}
          </p>
        </div>

        <div className="grid grid-cols-2 gap-y-4 gap-x-6 text-sm mt-8">
          {items.map((item, i) => (
            <div key={i} className="flex items-center gap-2 text-slate-300">
              <span className="w-2 h-2 bg-cyan-400 rounded-full"></span>
              {item}
            </div>
          ))}
        </div>

      </div>
    </motion.div>
  );
}