import { motion, AnimatePresence } from "framer-motion";

export default function ApplyModal({ open, onClose, position }) {
  return (
    <AnimatePresence>
      {open && (
        <>
          {/* BACKDROP */}
          <motion.div
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          {/* MODAL */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 40 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 40 }}
            transition={{ duration: 0.3 }}
            className="
              fixed z-50 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2
              w-[92%] max-w-xl
              rounded-2xl
              bg-[#0b1220]
              border border-blue-500/30
              shadow-[0_0_40px_rgba(59,130,246,0.35)]
              p-6
            "
          >
            {/* HEADER */}
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-white">
                Apply for {position}
              </h2>
              <button
                onClick={onClose}
                className="text-gray-400 hover:text-white text-xl"
              >
                ✕
              </button>
            </div>

            {/* FORM */}
            <form className="space-y-4">
              <input
                type="text"
                placeholder="Full Name"
                className="w-full bg-[#020617] border border-blue-500/30 rounded-lg px-4 py-3 text-white outline-none focus:border-blue-500"
              />

              <input
                type="email"
                placeholder="Email Address"
                className="w-full bg-[#020617] border border-blue-500/30 rounded-lg px-4 py-3 text-white outline-none focus:border-blue-500"
              />

              <input
                type="text"
                value={position}
                disabled
                className="w-full bg-[#020617] border border-blue-500/20 rounded-lg px-4 py-3 text-gray-400"
              />

              <input
                type="file"
                className="
                  w-full text-gray-300
                  file:bg-blue-500/10
                  file:border file:border-blue-500/30
                  file:text-blue-400
                  file:px-4 file:py-2
                  file:rounded-md
                "
              />

              <textarea
                rows="4"
                placeholder="Why should we hire you?"
                className="w-full bg-[#020617] border border-blue-500/30 rounded-lg px-4 py-3 text-white outline-none focus:border-blue-500"
              />

              <button
                type="submit"
                className="
                  w-full py-3 rounded-lg
                  bg-blue-500 text-white font-semibold
                  hover:bg-blue-600 transition
                "
              >
                Submit Application
              </button>
            </form>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
