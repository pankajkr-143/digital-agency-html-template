import React from 'react'

const Trusted = () => {
  return (
    <div>Trusted</div>
  )
}

export default Trusted